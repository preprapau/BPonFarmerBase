# farmerbase
Nepali FarmerBase Business Plan Management System
# farmerbase 🌾

farmerbase is a Nepali Farmer–Friendly Business Plan Management System (BPMS).

## के गर्न मिल्छ ?
- वार्षिक खर्च तथा आम्दानी योजना
- ५ वर्षे व्यवसायिक योजना
- लगानी फिर्ता अवधि (Payback Period)
- लगानीको प्रतिफल (ROI)
- लाभांश बाँडफाँट तथा लगानी योजना
- Proposal & Business Plan Auto Output

## कसका लागि ?
- किसान
- व्यवसायी
- सहकारी
- सरकारी / संघीय प्रस्तावना

## भाषा
- 100% नेपाली (Farmer Base)

## Demo Access
- Username: demo
- Password: demo123

## Status
Demo version – Live deployment in progress.

